#include <stdio.h>
#include <map>
#include <string>

using namespace std;

int main ()
{
  map<string, string> dict;

  dict.insert(make_pair("yes", "oui"));
  dict.insert(make_pair("no", "non"));
  dict.insert(make_pair("green", "vert"));
  dict.insert(make_pair("good", "bon"));

  char buffer[30];
  
  printf("Give me a word: ");
  scanf("%s", buffer);

  map<string, string>::iterator p;

  p = dict.find(buffer);
  if (p != dict.end()) 
    printf("In French: %s\n", p->second.c_str());
  else
    printf("OK, I can't really speak French!\n");

  return 0;
}
