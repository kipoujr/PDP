#include <stdlib.h>
#include <stdio.h>
#include <set>
#include <algorithm>

using namespace std;

#define max 10

int main ()
{
   set<int> s1, s2;
   
   s1.insert(3);
   s1.insert(5);
   s1.insert(2);
   s1.insert(8);
   s1.insert(7);
   
   s2.insert(7);
   s2.insert(3);
   s2.insert(2);

   if (includes(s1.begin(), s1.end(), s2.begin(), s2.end()))
      printf("s1 includes s2\n");
   else
      printf("s1 does not include s2\n");
   if (includes(s2.begin(), s2.end(), s1.begin(), s1.end()))
      printf("s2 includes s1\n");
   else
      printf("s2 does not include s1\n");

   return 0;   
}
