#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>

using namespace std;

#define max 15

int main ()
{
   vector<int> v(max);

   for (int i=0; i<max; i++)
      v[i] = rand() % 100;

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");
   
   sort(v.begin(), v.end());

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");

   int i;
   
   do {
      scanf("%d", &i);
      if (binary_search(v.begin(), v.end(), i))
         printf("Found\n");
      else
         printf("Not found\n");
   } while (i>0);

   return 0;
}
