#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

#define max 15

int main ()
{
   vector<int> v(max);

   // increasing
      
   for (int i=0; i<max; i++)
      v[i] = rand() % 100;

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");
   
   sort(v.begin(), v.end());

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");

   // decreasing

   for (int i=0; i<max; i++)
      v[i] = rand() % 100;

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");

   sort(v.begin(), v.end(), greater<int>());

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");

   return 0;
}
