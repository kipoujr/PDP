#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

struct bunch {
  int x, y, z;
};

bool operator < (const bunch &a, const bunch &b)
{
  if (a.x != b.x) return a.x < b.x;
  return a.y < b.y;
}

#define max 15

int main ()
{
   vector<bunch> v(max);

   // increasing
      
   for (int i=0; i<max; i++) {
      v[i].x = rand() % 100;
      v[i].y = rand() % 100;
      v[i].z = rand() % 100;
   }

   for (int i=0; i<max; i++)
     printf("(%d, %d, %d), ", v[i].x, v[i].y, v[i].z);
   printf("END\n");
   
   sort(v.begin(), v.end());
   // sort(v.begin(), v.end(), greater<int>());

   for (int i=0; i<max; i++)
     printf("(%d, %d, %d), ", v[i].x, v[i].y, v[i].z);
   printf("END\n");

   return 0;
}
