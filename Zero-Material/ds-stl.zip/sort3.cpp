#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

#define max 15
#define num 5

int main ()
{
   vector<int> v(max);

   for (int i=0; i<max; i++)
      v[i] = rand() % 100;

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");
   
   nth_element(v.begin(), v.begin() + num, v.end());

   printf("nth = %d\n", v[num]);
   
   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");

   return 0;
}
