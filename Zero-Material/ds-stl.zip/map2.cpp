#include <stdio.h>
#include <map>
#include <string>

using namespace std;

int main ()
{
  map<string, string> dict;

  dict["yes"] = "oui";
  dict["no"] = "non";
  dict["green"] = "vert";
  dict["good"] = "bon";

  char buffer[30];
  
  printf("Give me a word: ");
  scanf("%s", buffer);

  if (!dict[buffer].empty())
    printf("In French: %s\n", dict[buffer].c_str());
  else
    printf("OK, I can't really speak French!\n");

  return 0;
}
