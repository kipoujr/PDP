#include <stdio.h>
#include <queue>
#include <functional>

using namespace std;

int main ()
{
   priority_queue< int, vector<int>, greater<int> > q;

   /* This program would generate all Hamming numbers in increasing order:
        { 2^n * 3^m * 5^p | n, m, p \in N }
      if we didn't stop it too early...
   */

   q.push(1);
   
   for (int i=0; i<20; i++) {
      int h = q.top();
      printf("%d, ", h);
      q.pop();
      q.push(2*h);
      if (h % 2 != 0)
         q.push(3*h);
      if (h % 2 != 0 && h % 3 != 0)
         q.push(5*h);
   }
   printf("END\n");

   return 0;
}
