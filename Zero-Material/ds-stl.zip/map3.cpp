#include <stdio.h>
#include <map>

using namespace std;

long stupid_fib (long n)
{
   return (n <= 1) ? 1 : stupid_fib(n-1) + stupid_fib(n-2);
}

long memo_fib (long n)
{
   static map<long, long> m;
   map<long, long>::iterator p = m.find(n);

   if (p==m.end()) {
      long r = (n <= 1) ? 1 : memo_fib(n-1) + memo_fib(n-2);
      m[n] = r;
      return r;
   }
   else
      return p->second;
}

int main ()
{
   int i;
   
   do {
      scanf("%d", &i);
      
      printf("\astupid_fib(%2d) = ", i); fflush(stdout);
      printf("%15ld\a\t", stupid_fib(i)); fflush(stdout);
   
      printf("memo_fib(%2d) = ", i); fflush(stdout);
      printf("%15ld\a\n", memo_fib(i)); fflush(stdout);
   } while (i>0);
      
   return 0;
}
