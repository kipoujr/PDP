#include <stdio.h>
#include <list>

using namespace std;

int main ()
{
   list<int> l;
   
   for (int i=1; i<=5; i++)
      l.push_back(i);

   list<int>::iterator i;

   for (i=l.begin(); i!=l.end(); i++)
      for (int j=1; j<*i; j++)
         l.insert(i, -*i);

   for (i=l.begin(); i!=l.end(); i++)
      printf("%d, ", *i);
   printf("END\n");

   for (i=l.begin(); i!=l.end(); )
      if (*i % 2 == 0) {
         list<int>::iterator j = i++;
         l.erase(j);
      }
      else
         i++;

   for (i=l.begin(); i!=l.end(); i++)
      printf("%d, ", *i);
   printf("END\n");

   return 0;
}
