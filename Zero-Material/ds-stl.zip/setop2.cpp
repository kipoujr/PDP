#include <stdlib.h>
#include <stdio.h>
#include <set>
#include <algorithm>

using namespace std;

#define max 10

void print (set<int> s)
{
   set<int>::iterator i;

   for (i=s.begin(); i!=s.end(); i++)
      printf("%d, ", *i);
   printf("END\n");
}

int main ()
{
   set<int> s1, s2, s;
   
   s1.insert(3);
   s1.insert(5);
   s1.insert(2);
   s1.insert(8);
   s1.insert(7);
   
   printf("s1: ");
   print(s1);
   
   s2.insert(4);
   s2.insert(7);
   s2.insert(1);
   s2.insert(3);
   s2.insert(2);

   printf("s2: ");
   print(s2);
   
   set_union(s1.begin(), s1.end(), s2.begin(), s2.end(),
             inserter(s, s.begin()));
   printf("union: ");
   print(s);

   s.clear();   

   set_intersection(s1.begin(), s1.end(), s2.begin(), s2.end(),
                    inserter(s, s.begin()));
   printf("intersection: ");
   print(s);

   s.clear();   

   set_difference(s1.begin(), s1.end(), s2.begin(), s2.end(),
                  inserter(s, s.begin()));
   printf("difference: ");
   print(s);

   return 0;   
}
