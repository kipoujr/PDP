#include <stdio.h>
#include <stack>

using namespace std;

bool match (char open, char close)
{
   if ((open == '(' && close == ')') ||
       (open == '[' && close == ']') ||
       (open == '{' && close == '}'))
      return true;
   else {
      printf("Mismatch: %c with %c\n", open, close);
      return false;
   }
}

int main ()
{
   stack<char> s;
   char c;
   
   while ((c = getchar()) != '\n')
      switch (c) {
         case '(':
         case '[':
         case '{':
            s.push(c);
            break;
         case ')':
         case ']':
         case '}':
            if (s.empty())
               printf("Mismatch: %c but does not open\n", c);
            else if (match(s.top(), c))
               s.pop();
            break;
      }

   if (s.empty())
      printf("OK\n");
   else
      printf("Missing %d symbols at the end\n", s.size());

   return 0;
}
