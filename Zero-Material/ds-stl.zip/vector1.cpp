#include <stdio.h>
#include <vector>

using namespace std;

int main ()
{
   vector<int> v(100);
   
   for (int i=0; i<100; i++)
      v[i] = i*i;

   printf("v[42] = %d\n", v[42]);
   printf("size of v = %d\n", v.size());

   v.push_back(666);
   printf("v[100] = %d\n", v[100]);
   printf("size of v = %d\n", v.size());

   v.pop_back();
   printf("size of v = %d\n", v.size());

   return 0;
}
