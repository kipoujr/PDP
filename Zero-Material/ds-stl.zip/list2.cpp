#include <stdio.h>
#include <list>

using namespace std;

int main ()
{
   list<int> l;
   
   for (int i=1; i<=5; i++)
      l.push_back(i);

   list<int>::iterator i;

   for (i=l.begin(); i!=l.end(); i++)
     printf("%d, ", *i);
   printf("END\n");

   list<int>::reverse_iterator j;

   for (j=l.rbegin(); j!=l.rend(); j++)
      printf("%d, ", *j);
   printf("END\n");

   return 0;
}
