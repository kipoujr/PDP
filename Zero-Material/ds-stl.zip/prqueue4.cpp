#include <stdio.h>
#include <queue>

using namespace std;

typedef struct { int x, y; } coord;

#if 0
bool operator < (const coord & a, const coord & b)
{
  return a.x < b.x || a.x == b.x && a.y < b.y;
}
#endif

int main ()
{
   priority_queue<coord> q;

   coord a = { 3, 4 };
   coord b = { 5, 7 };
   coord c = { 1, 2 };

   q.push(a);
   q.push(b);
   q.push(c);
   while (!q.empty()) {
      coord t = q.top();
      printf("%d, %d\n", t.x, t.y);
      q.pop();
   }

   return 0;
}
