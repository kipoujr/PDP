#include <stdio.h>
#include <vector>
#include <algorithm>

using namespace std;

#define max 5

int main ()
{
   vector<int> v(max);
 
   v[0]=1; v[1]=1; v[2]=2; v[3]=2; v[4]=2;
 
   int count = 0;
   
   do {
      printf("permutation %3d:\t", ++count);
      for (int i=0; i<max; i++)
         printf("%d, ", v[i]);
      printf("END\n");
   } while (next_permutation(v.begin(), v.end()));
   

   return 0;
}
