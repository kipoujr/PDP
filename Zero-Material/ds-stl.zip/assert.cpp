#define NDEBUG

#include <assert.h>

int main ()
{
   assert(1==1);  // right!
   assert(1==0);  // wrong!
   
   return 0;
}
