#include <stdio.h>
#include <list>

using namespace std;

int main ()
{
   list<int> l;
   
   for (int i=0; i<10; i++)
      if (i % 2 == 0)
         l.push_front(i);
      else
         l.push_back(i);

   for (int i=0; !l.empty(); i++)
      if (i % 2 == 0) {
         printf("%d, ", l.back());
         l.pop_back();
      }
      else {
         printf("%d, ", l.front());
         l.pop_front();
      }
   printf("END\n");

   return 0;
}
