#include <stdio.h>
#include <queue>

using namespace std;

int main ()
{
   priority_queue<int> q;
   int n;

   while (scanf("%d", &n) == 1)
      q.push(n);

   while (!q.empty()) {
      printf("%d, ", q.top());
      q.pop();
   }
   printf("END\n");

   return 0;
}
