#include <stdio.h>
#include <vector>

using namespace std;

int main ()
{
   vector<bool> v(10000);
   
   for (int i=0; i<10000; i++)
      v[i] = true;

   for (int i=2; i<100; i++)
      if (v[i])
         for (int j=i*i; j<10000; j+=i)
            v[j] = false;

   for (int i=2; i<10000; i++)
      if (v[i])
         printf("%d, ", i);
   printf("END\n");
   
   return 0;
}
