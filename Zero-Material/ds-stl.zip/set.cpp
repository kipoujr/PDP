#include <stdio.h>
#include <set>

using namespace std;

#define max 100

int main ()
{
   set<int> s;
   
   for (int i=2; i<=max; i++)
      s.insert(i);
      
   set<int>::iterator i;
      
   for (i=s.begin(); *i * *i <= max; i++) {
      set<int>::iterator j=i;
      j++;
      
      while (j!=s.end())
         if (*j % *i == 0) {
            set<int>::iterator k = j++;
            s.erase(k);
         }
         else
            j++;
   }

   for (i=s.begin(); i!=s.end(); i++)
      printf("%d, ", *i);
   printf("END\n");

   return 0;   
}
