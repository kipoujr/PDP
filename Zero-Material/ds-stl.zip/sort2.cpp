#include <stdio.h>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;

#define max 15
#define num 5

int main ()
{
   vector<int> v(max);

   // find 5 greatest
      
   for (int i=0; i<max; i++)
      v[i] = rand() % 100;

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");
   
   partial_sort(v.begin(), v.begin() + num, v.end(),
                greater<int>());

   for (int i=0; i<max; i++)
      printf("%d, ", v[i]);
   printf("END\n");

   return 0;
}
