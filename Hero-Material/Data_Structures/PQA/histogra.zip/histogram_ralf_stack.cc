/*
 * University of Ulm Local Contest 2003
 * Problem H: Largest Rectangle in a Histogram
 * Ralf Gandy
 * Jun 02, 2003
 */
#include <fstream>
#include <iostream>
#include <stack>

using namespace std;

#define areatype double

ifstream in("histogram.in");
int n;

int main()
{
	while (in >> n)
	{
		if (n == 0)
			break;
		
		stack<pair<double, int> > since;
		areatype maxarea = 0.0;
		areatype h;
		
		for (int i = 0; i < n; i++)
		{
			in >> h;

			int h_since = i;
			while (!since.empty())
			{
				if (since.top().first == h)
					goto skip_insertion;

				if (since.top().first < h)
					break;

				h_since = since.top().second;

				if (since.top().first * (i - since.top().second) > maxarea)
					maxarea = since.top().first * (i - since.top().second);
				
				since.pop();
			}

			since.push(pair<areatype, int>(h, h_since));

		skip_insertion:
			;
		}
		while (!since.empty())
		{
			if (since.top().first * (n - since.top().second) > maxarea)
				maxarea = since.top().first * (n - since.top().second);
			since.pop();
		}

		cout.setf(ios::fixed, ios::floatfield);
		cout.precision(0);
		
		cout << maxarea << endl;
	}
	return 0;
}
