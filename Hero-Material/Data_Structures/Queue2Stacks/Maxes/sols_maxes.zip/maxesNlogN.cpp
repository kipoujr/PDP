#include <bits/stdc++.h>
using namespace std;
#define MAXN 1000000
typedef long long ll;
multiset<ll> S;
vector<ll> val;
ll A[MAXN+5];

int main() {
  int N, K, M, O;
  scanf("%d %d %d %d", &N, &K, &M, &O);
  for(int i=1; i<=N; ++i) {
	scanf("%lld", &A[i]);	
	S.insert(A[i]);
	if(i>K) {
	  S.erase( S.find(A[i-K]) );}
	if(i>=K) {
	  ll s = 0;
	  auto pos=S.end();
	  --pos;
	  for(int j=1; j<=M; ++j, --pos) {
		s += *pos;}
	  val.push_back(s);}}
  nth_element(val.begin(), val.begin()+O-1, val.end());
  printf("%lld\n", val[O-1]);}
