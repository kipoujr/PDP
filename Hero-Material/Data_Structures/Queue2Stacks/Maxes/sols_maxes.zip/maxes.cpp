#include <bits/stdc++.h>
using namespace std;
#define MAXN 1000000
#define MAXM 5
typedef long long ll;

struct Maxes {
  ll currVal;
  ll A[MAXM];
  Maxes(ll val) {
	currVal = A[0] = val;
	for(int i=1; i<MAXM; ++i) {
	  A[i] = 0;}}
  Maxes() {
    for(int i=0; i<MAXM; ++i) {
	  A[i] = 0;}}
  void Print() {
	printf("Value is %lld and maxes:\n", currVal);
	for(int i=0; i<MAXM; ++i) {
	  printf("%lld\n", A[i]);}}
  ll Sum(int M) {
	ll s=0;
	for(int i=0; i<M; ++i) {
	  s+=A[i];}
	return s;}
  Maxes Mix(Maxes a) {
	Maxes ans(a.currVal);
	int lCnt=0, rCnt=0;
	for(int i=0; i<MAXM; ++i) {
	  ans.A[i] = (A[lCnt] >= a.A[rCnt]) ? A[lCnt++] : a.A[rCnt++];}
	return ans;}};

ll mix(vector<Maxes>& stInp, vector<Maxes>& stOut, int M) {
  return (stInp.size()?stInp.back():Maxes()).Mix(stOut.size()?stOut.back():Maxes()).Sum(M);}

void Enqueue(vector<Maxes>& stInp, ll val) {
  if (stInp.size()) {
	stInp.push_back( stInp.back().Mix(Maxes(val)) );}
  else {
	stInp.push_back(Maxes(val));}}

void Dequeue(vector<Maxes>& stInp, vector<Maxes>& stOut) {
  if( stOut.size() == 0 ) {
	while( stInp.size() ) {
	  Enqueue(stOut, stInp.back().currVal);
	  stInp.pop_back();}}
  stOut.pop_back();}

int main() {
  int N, K, M, O;
  ll curr;
  vector<ll> val;
  vector<Maxes> stInp, stOut;  
  scanf("%d %d %d %d", &N, &K, &M, &O);
  for(int i=1; i<=N; ++i) {
	scanf("%lld", &curr);
	Enqueue(stInp, curr);
	if(i>K) {
	  Dequeue(stInp, stOut);}
	if(i>=K) {
	  val.push_back(mix(stInp, stOut, M));}}
  nth_element(val.begin(), val.begin()+O-1, val.end());
  printf("%lld\n", val[O-1]);}
