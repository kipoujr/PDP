#include <cstdio>
#include <cstring>
#include <algorithm>
#define FOR(i,s,e) for (int i=(s); i<(e); i++)
#define SZ 2500100
using namespace std;

struct node{
	int p[26], f, v;
	void init(){
		f = v = 0;
		for (int i=0; i<26; i++) p[i] = 0;
	}
}   T[SZ];

int n, m, t, cnt, ret;
int q[SZ], v[300005];
char s[300005], tile[5005];

void add(char s[]){
	int x = 0, c, n = strlen(s);
	for (int i=0; i<n; i++){
		c = s[i] - 'a';
		if (!T[x].p[c]) T[x].p[c] = ++t, T[t].init();
		x = T[x].p[c];
	}
	T[x].v = n;
}

void build(){
	int x, y, t;
	q[0] = 0;
	T[0].f = -1;

	for (int i=0, j=0; j>=i; i++){
		x = q[i];
		for (int k=0; k<26; k++){
			y = T[x].p[k];
			if (y){
				t = T[x].f;
				while (t >= 0 && !T[t].p[k]) t = T[t].f;
				if (t < 0) T[y].f = 0;
				else T[y].f = T[t].p[k];
				T[y].v = max(T[y].v, T[T[y].f].v);
				q[++j] = y;
			}
		}
	}
}

void match(char s[]){
	int x = 0, c, t, n = strlen(s);
	for (int i=0; i<n; i++){
		c = s[i] - 'a';
		while (x > 0 && !T[x].p[c]) x = T[x].f;
		x = T[x].p[c];

		if (T[x].v){
			v[i-T[x].v+1]++;
			v[i+1]--;
		}
	}
}


int main(){
	scanf("%d%s", &n, s);
	scanf("%d", &m);
	
	FOR(i,0,m){
		scanf("%s", tile);
		add(tile);
		cnt++;

		if (cnt >= 500 || i == m-1){
			build();
			match(s);
			T[0].init();
			cnt = 0;
		}
	}
	
	cnt = 0;
	FOR(i,0,n){
		cnt += v[i];
		ret += cnt == 0;
	}
	printf("%d\n", ret);
	return 0;
}
