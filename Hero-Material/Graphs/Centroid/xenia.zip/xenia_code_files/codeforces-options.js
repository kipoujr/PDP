window.codeforcesOptions = [];
window.codeforcesOptions.subscribeServerUrl = "pubsub.codeforces.com";
window.codeforcesOptions.standaloneGroupDomain = "contest.codeforces.com";
window.codeforcesOptions.timeZoneNoticeCaption = "in timezone UTC";
window.codeforcesOptions.timeZoneTitleCaption = "timezone offset";
window.codeforcesOptions.notPublicCaption = "not publicly available";